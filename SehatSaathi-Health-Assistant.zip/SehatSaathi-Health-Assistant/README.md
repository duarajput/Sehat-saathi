# SehatSaathi

SehatSaathi is a health-information assistant for users in Pakistan. It helps a care team test safe Urdu and English guidance, preview WhatsApp message flows, schedule user-provided reminders, and find nearby clinics or pharmacies around Hyderabad, Sindh.

It is an information tool, not a doctor. It never diagnoses conditions, prescribes medicines, changes doses, or tells a user to stop prescribed treatment. Possible emergency symptoms are surfaced with a clear recommendation to seek urgent professional help.

## Features

- Responsive care-operations dashboard with live summary cards and recent activity
- Urdu, Roman Urdu, and English assistant demo with language detection
- Emergency-aware responses with visible safety boundaries
- Demo Mode that works without external credentials
- WhatsApp Cloud API webhook for text messages and a clear voice-message fallback
- User-created medicine reminders with Pakistan Standard Time defaults
- Optional reminder delivery through WhatsApp when a phone number is supplied to the API
- Nearby Hyderabad clinic and pharmacy directory with Google Maps links
- Settings page with integration guidance and safety disclaimer

## Technology

- React + Vite frontend
- Node.js + Express API server
- TypeScript across the workspace
- OpenAPI contract with generated React Query hooks and Zod validators
- Optional Gemini, WhatsApp Cloud API, and Google Places integrations
- In-memory development store so the prototype remains usable without a database

## Run locally in Replit

Use the Run button, or start the two services with:

```bash
pnpm --filter @workspace/api-server run dev
pnpm --filter @workspace/sehat-saathi run dev
```

The managed workflows provide `PORT` and the routed base paths. The frontend is served at the root preview and calls the API through `/api`.

## Configuration

Copy `.env.example` to your environment settings. Never commit or expose real credentials.

### Gemini

Set `GEMINI_API_KEY` to enable live responses from Gemini 2.5 Flash. Without it, the server uses conservative, clearly labelled Demo Mode responses. The server-side safety prompt is in `artifacts/api-server/src/services/health-assistant.ts`.

### WhatsApp Cloud API

Set:

- `WHATSAPP_ACCESS_TOKEN`
- `WHATSAPP_PHONE_NUMBER_ID`
- `WHATSAPP_VERIFY_TOKEN`

Configure the WhatsApp webhook URL as `/webhook/whatsapp`. The GET endpoint verifies the webhook and the POST endpoint handles text messages. Audio messages receive a clear configuration response because the prototype does not claim to transcribe voice without a transcription provider.

### Google Maps / Places

Set `GOOGLE_MAPS_API_KEY` to enable Google Places Text Search. Without it, the nearby-places screen uses sample Hyderabad results and labels opening hours as unavailable rather than guessing.

## Demo Mode

Demo Mode is automatic when credentials are missing. The dashboard, chat, reminders, WhatsApp sample flow, and nearby-place directory all remain usable. Demo data is exposed in the API responses and labelled in the UI. Adding a configured provider automatically enables that provider's live path; unavailable provider calls fall back safely.

## API

- `GET /api/health` — service health
- `GET /api/healthz` — compatibility health check
- `GET /api/dashboard` — dashboard summary
- `POST /api/chat` — safe health-information response
- `GET /api/reminders` — active reminders
- `POST /api/reminders` — create a reminder
- `DELETE /api/reminders/:id` — delete a reminder
- `GET /api/places?type=clinic&city=Hyderabad` — nearby care results
- `GET /api/whatsapp/status` — channel status and sample messages
- `GET /webhook/whatsapp` — WhatsApp verification
- `POST /webhook/whatsapp` — WhatsApp inbound messages

## Deploy

The web artifact is ready to publish from Replit. Add production environment variables before enabling live provider calls, and have a qualified clinician review the safety language before using SehatSaathi with real users.

## Medical safety disclaimer

SehatSaathi provides general health information and is not a replacement for a qualified doctor or emergency medical care. For severe breathing difficulty, unconsciousness, severe chest pain, severe allergic reaction, serious injury, seizure, sudden severe weakness, severe bleeding, poisoning, suspected overdose, or any rapidly worsening situation, seek emergency professional help immediately.