# SehatSaathi

An AI-powered health-information assistant for Pakistan with safe bilingual chat, care-team operations, reminders, WhatsApp flows, and nearby care discovery.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Optional env: `GEMINI_API_KEY`, `WHATSAPP_ACCESS_TOKEN`, `WHATSAPP_PHONE_NUMBER_ID`, `WHATSAPP_VERIFY_TOKEN`, `GOOGLE_MAPS_API_KEY`

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/sehat-saathi/src/App.tsx` — responsive frontend routes and shared care-operations shell
- `artifacts/sehat-saathi/src/index.css` — SehatSaathi visual tokens and responsive styling
- `artifacts/api-server/src/routes/` — API, webhook, reminder, places, and WhatsApp routes
- `artifacts/api-server/src/services/` — in-memory demo store, safety assistant, provider adapters, and reminder scheduler
- `lib/api-spec/openapi.yaml` — API source of truth; regenerate hooks after edits
- `.env.example` — optional provider configuration placeholders

## Architecture decisions

- The API always remains usable without provider credentials; provider calls are optional and fall back to explicit Demo Mode behavior.
- Health responses run through a server-side safety prompt and a deterministic urgent-symptom guard before live model calls.
- Demo persistence uses an in-memory store for a fast prototype; the API shapes are ready to move behind PostgreSQL later.
- Google Places results never claim opening hours unless the provider returns trustworthy hours data.

## Product

SehatSaathi gives Pakistan-focused care teams a single place to review safe bilingual assistant behavior, inspect WhatsApp activity, schedule user-provided reminders, and locate nearby clinics and pharmacies around Hyderabad.

## User preferences

No additional preferences recorded.

## Gotchas

- Never expose provider keys in frontend code.
- After changing `lib/api-spec/openapi.yaml`, run `pnpm --filter @workspace/api-spec run codegen`.
- Provider credentials are optional in Demo Mode; do not turn missing credentials into startup crashes.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
