import { type ReactNode, useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Link, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import {
  Activity,
  ArrowUpRight,
  Bell,
  BookOpen,
  Check,
  ChevronRight,
  CircleAlert,
  Clock3,
  Code2,
  Crosshair,
  ExternalLink,
  HeartPulse,
  Hospital,
  Inbox,
  LayoutDashboard,
  LoaderCircle,
  MapPin,
  Menu,
  MessageCircle,
  MoreHorizontal,
  Pill,
  Plus,
  RefreshCw,
  Send,
  Settings,
  ShieldCheck,
  Smartphone,
  Trash2,
  UserRound,
  Users,
  X,
} from 'lucide-react';
import {
  getGetDashboardQueryKey,
  getGetWhatsAppStatusQueryKey,
  getHealthCheckQueryKey,
  getListPlacesQueryKey,
  getListRemindersQueryKey,
  useCreateReminder,
  useDeleteReminder,
  useGetDashboard,
  useGetWhatsAppStatus,
  useHealthCheck,
  useListPlaces,
  useListReminders,
  useSendChatMessage,
} from '@workspace/api-client-react';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();

const navItems = [
  { href: '/', label: 'Overview', icon: LayoutDashboard },
  { href: '/assistant', label: 'Health assistant', icon: MessageCircle },
  { href: '/reminders', label: 'Reminders', icon: Bell },
  { href: '/places', label: 'Nearby places', icon: MapPin },
  { href: '/whatsapp', label: 'WhatsApp channel', icon: Smartphone },
];

function formatTime(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString('en-PK', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' });
}

function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const health = useHealthCheck({ query: { queryKey: getHealthCheckQueryKey(), refetchInterval: 30000 } });
  const pageTitle = navItems.find((item) => item.href === location)?.label ?? 'Settings';

  return (
    <div className="noise min-h-[100dvh] bg-background">
      <div className={`fixed inset-0 z-40 bg-[#071f24]/45 transition-opacity md:hidden ${mobileOpen ? 'opacity-100' : 'pointer-events-none opacity-0'}`} onClick={() => setMobileOpen(false)} />
      <aside className={`fixed inset-y-0 left-0 z-50 flex w-[268px] flex-col bg-sidebar px-5 py-6 text-sidebar-foreground transition-transform duration-300 md:translate-x-0 ${mobileOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex items-center justify-between px-2">
          <Link href="/" className="flex items-center gap-3" data-testid="link-brand">
            <span className="grid h-10 w-10 place-items-center rounded-[13px] bg-accent text-accent-foreground shadow-sm"><HeartPulse size={21} strokeWidth={2.5} /></span>
            <span><span className="block font-serif text-lg font-semibold tracking-tight">SehatSaathi</span><span className="block text-[10px] font-medium uppercase tracking-[.18em] text-sidebar-foreground/55">care operations</span></span>
          </Link>
          <button className="rounded-lg p-2 text-sidebar-foreground/60 hover:bg-sidebar-accent md:hidden" onClick={() => setMobileOpen(false)} data-testid="button-close-menu"><X size={18} /></button>
        </div>
        <div className="mt-10 px-2 text-[10px] font-semibold uppercase tracking-[.18em] text-sidebar-foreground/40">Workspace</div>
        <nav className="mt-3 flex-1 space-y-1">
          {navItems.map(({ href, label, icon: Icon }) => {
            const active = location === href;
            return <Link key={href} href={href} onClick={() => setMobileOpen(false)} className={`group flex items-center justify-between rounded-xl px-3 py-3 text-sm transition-all ${active ? 'bg-sidebar-primary font-semibold text-sidebar-primary-foreground shadow-[0_8px_18px_-10px_hsl(38_91%_61%/.7)]' : 'text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground'}`} data-testid={`link-nav-${label.toLowerCase().replaceAll(' ', '-')}`}>
              <span className="flex items-center gap-3"><Icon size={17} strokeWidth={active ? 2.4 : 1.8} /><span>{label}</span></span>
              {active && <ChevronRight size={15} />}
            </Link>;
          })}
          <Link href="/settings" onClick={() => setMobileOpen(false)} className={`group flex items-center justify-between rounded-xl px-3 py-3 text-sm transition-all ${location === '/settings' ? 'bg-sidebar-primary font-semibold text-sidebar-primary-foreground' : 'text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground'}`} data-testid="link-nav-settings">
            <span className="flex items-center gap-3"><Settings size={17} /><span>Settings</span></span>
            {location === '/settings' && <ChevronRight size={15} />}
          </Link>
        </nav>
        <div className="rounded-2xl border border-sidebar-border bg-sidebar-accent/55 p-4">
          <div className="flex items-center gap-2 text-xs font-semibold"><span className={`h-2 w-2 rounded-full ${health.isError ? 'bg-destructive' : 'bg-[#91d9aa]'} pulse-line`} /> Platform {health.isError ? 'unavailable' : 'operational'}</div>
          <p className="mt-2 text-[11px] leading-relaxed text-sidebar-foreground/50">For care teams supporting families across Sindh.</p>
        </div>
        <div className="mt-5 flex items-center gap-3 border-t border-sidebar-border px-2 pt-5">
          <span className="grid h-8 w-8 place-items-center rounded-full bg-[#d9c29d] text-xs font-bold text-[#193c40]">CT</span>
          <div className="min-w-0"><p className="truncate text-xs font-semibold">Care team</p><p className="truncate text-[11px] text-sidebar-foreground/45">Hyderabad, PK</p></div>
          <MoreHorizontal size={17} className="ml-auto text-sidebar-foreground/40" />
        </div>
      </aside>
      <main className="min-h-[100dvh] md:pl-[268px]">
        <header className="sticky top-0 z-30 flex h-[76px] items-center justify-between border-b border-border/70 bg-background/90 px-5 backdrop-blur-md md:px-10">
          <div className="flex items-center gap-3"><button className="rounded-xl border border-border bg-card p-2.5 md:hidden" onClick={() => setMobileOpen(true)} data-testid="button-open-menu"><Menu size={18} /></button><div><p className="hidden text-[10px] font-semibold uppercase tracking-[.18em] text-muted-foreground sm:block">SehatSaathi / {pageTitle}</p><h1 className="font-serif text-xl font-semibold tracking-tight md:text-2xl">{pageTitle}</h1></div></div>
          <div className="flex items-center gap-3"><span className="hidden items-center gap-2 rounded-full border border-border bg-card px-3 py-2 text-xs text-muted-foreground sm:flex"><span className="h-1.5 w-1.5 rounded-full bg-[#5ba776]" /> Live workspace</span><button className="grid h-9 w-9 place-items-center rounded-full border border-border bg-card text-primary transition hover:border-primary/40 hover:bg-muted" data-testid="button-profile"><UserRound size={16} /></button></div>
        </header>
        <div className="mx-auto max-w-[1440px] px-5 py-7 md:px-10 md:py-9">{children}</div>
      </main>
    </div>
  );
}

function SectionHeading({ eyebrow, title, detail, action }: { eyebrow?: string; title: string; detail?: string; action?: ReactNode }) {
  return <div className="mb-7 flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div>{eyebrow && <p className="mb-2 text-[10px] font-bold uppercase tracking-[.2em] text-[#9b6816]">{eyebrow}</p>}<h2 className="font-serif text-3xl font-semibold tracking-[-.04em] text-primary md:text-[38px]">{title}</h2>{detail && <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted-foreground">{detail}</p>}</div>{action}</div>;
}

function ErrorNotice({ onRetry, label = 'Could not load this view.' }: { onRetry?: () => void; label?: string }) {
  return <div className="flex items-center justify-between gap-4 rounded-2xl border border-destructive/20 bg-[#f8e9e5] p-4 text-sm text-[#74382f]" data-testid="status-error"><span className="flex items-center gap-2"><CircleAlert size={17} />{label}</span>{onRetry && <button onClick={onRetry} className="rounded-lg border border-[#c98579]/40 px-3 py-1.5 text-xs font-semibold hover:bg-[#f4d9d3]" data-testid="button-retry">Retry</button>}</div>;
}

function StatCard({ icon: Icon, label, value, note, accent }: { icon: typeof Users; label: string; value: string | number; note: string; accent: string }) {
  return <div className="group relative overflow-hidden rounded-2xl border border-border/80 bg-card p-5 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-md"><div className={`mb-7 grid h-10 w-10 place-items-center rounded-xl ${accent}`}><Icon size={18} /></div><p className="text-xs font-medium text-muted-foreground">{label}</p><p className="mt-1 font-serif text-[34px] font-semibold leading-none tracking-[-.04em] text-primary" data-testid={`text-stat-${label.toLowerCase().replaceAll(' ', '-')}`}>{value}</p><p className="mt-3 text-[11px] text-muted-foreground">{note}</p><div className="absolute -right-8 -top-8 h-24 w-24 rounded-full border-[12px] border-primary/[.035] transition-transform duration-500 group-hover:scale-150" /></div>;
}

function Overview() {
  const { data, isLoading, isError, refetch } = useGetDashboard({ query: { queryKey: getGetDashboardQueryKey(), refetchInterval: 60000 } });
  const summary = data ?? { totalUsers: 0, messagesProcessed: 0, healthQuestionsToday: 0, activeReminders: 0, demoMode: false, recentActivity: [] };
  return <div className="page-enter">
    <SectionHeading eyebrow="Tuesday · 18 June 2024" title="Good morning, care team." detail="A clear view of the people, questions, and follow-ups moving through your workspace today." action={<Link href="/assistant" className="inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground shadow-sm transition hover:-translate-y-0.5 hover:bg-[#24545a]" data-testid="link-open-assistant">Open assistant <ArrowUpRight size={16} /></Link>} />
    {isError && <div className="mb-5"><ErrorNotice onRetry={() => refetch()} /></div>}
    {isLoading ? <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">{[1, 2, 3, 4].map((item) => <div key={item} className="h-[190px] animate-pulse rounded-2xl bg-muted" />)}</div> : <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
      <StatCard icon={Users} label="People supported" value={summary.totalUsers.toLocaleString()} note="all time in workspace" accent="bg-[#dce9e3] text-[#2e6659]" />
      <StatCard icon={MessageCircle} label="Messages processed" value={summary.messagesProcessed.toLocaleString()} note="across every channel" accent="bg-[#f5e3bd] text-[#9b6816]" />
      <StatCard icon={Activity} label="Questions today" value={summary.healthQuestionsToday} note="since midnight PKT" accent="bg-[#e7dfed] text-[#75547e]" />
      <StatCard icon={Bell} label="Active reminders" value={summary.activeReminders} note="next 7 days" accent="bg-[#e8d9d1] text-[#8c594a]" />
    </div>}
    <div className="mt-7 grid gap-6 xl:grid-cols-[1.45fr_1fr]">
      <section className="rounded-2xl border border-border/80 bg-card p-5 shadow-sm md:p-6">
        <div className="flex items-center justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[.18em] text-muted-foreground">Signal log</p><h3 className="mt-1 font-serif text-xl font-semibold text-primary">Recent activity</h3></div><button className="rounded-lg p-2 text-muted-foreground hover:bg-muted hover:text-primary" onClick={() => refetch()} data-testid="button-refresh-dashboard"><RefreshCw size={16} /></button></div>
        <div className="mt-5 divide-y divide-border/70">{summary.recentActivity.length ? summary.recentActivity.map((item) => <div key={item.id} className="flex gap-3 py-4 first:pt-0 last:pb-0" data-testid={`activity-${item.id}`}><span className={`mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg ${item.kind === 'message' ? 'bg-[#e7dfed] text-[#75547e]' : item.kind === 'reminder' ? 'bg-[#f5e3bd] text-[#9b6816]' : item.kind === 'place' ? 'bg-[#dce9e3] text-[#2e6659]' : 'bg-[#e8d9d1] text-[#8c594a]'}`}>{item.kind === 'message' ? <MessageCircle size={15} /> : item.kind === 'reminder' ? <Bell size={15} /> : item.kind === 'place' ? <MapPin size={15} /> : <Smartphone size={15} />}</span><div className="min-w-0 flex-1"><div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1"><p className="text-sm font-semibold text-primary">{item.title}</p><span className="text-[11px] text-muted-foreground">{formatTime(item.time)}</span></div><p className="mt-1 text-xs leading-relaxed text-muted-foreground">{item.detail}</p></div></div>) : <EmptyState icon={Inbox} title="No activity yet" detail="New conversations and care actions will appear here." compact />}</div>
      </section>
      <section className="relative overflow-hidden rounded-2xl bg-primary p-6 text-primary-foreground shadow-md md:p-7"><div className="absolute -right-16 -top-20 h-56 w-56 rounded-full border-[22px] border-accent/10" /><div className="relative"><span className="inline-flex items-center gap-2 rounded-full border border-primary-foreground/15 bg-primary-foreground/10 px-3 py-1.5 text-[10px] font-bold uppercase tracking-[.16em] text-accent"><ShieldCheck size={13} /> Safety first</span><h3 className="mt-7 max-w-xs font-serif text-3xl font-semibold leading-[1.02] tracking-[-.04em]">Information that knows its limits.</h3><p className="mt-4 max-w-sm text-sm leading-relaxed text-primary-foreground/65">Every response is a starting point for a safer conversation, never a substitute for a qualified clinician.</p><Link href="/settings" className="mt-7 inline-flex items-center gap-2 text-sm font-semibold text-accent hover:underline" data-testid="link-safety-guidance">Review safety guidance <ArrowUpRight size={15} /></Link></div></section>
    </div>
  </div>;
}

function EmptyState({ icon: Icon, title, detail, compact = false }: { icon: typeof Inbox; title: string; detail: string; compact?: boolean }) {
  return <div className={`flex flex-col items-center justify-center text-center ${compact ? 'py-8' : 'py-16'}`} data-testid="empty-state"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-muted text-muted-foreground"><Icon size={21} /></span><p className="mt-4 text-sm font-semibold text-primary">{title}</p><p className="mt-1 max-w-xs text-xs leading-relaxed text-muted-foreground">{detail}</p></div>;
}

function Assistant() {
  const chat = useSendChatMessage();
  const [message, setMessage] = useState('');
  const [language, setLanguage] = useState<'auto' | 'en' | 'ur'>('auto');
  const [history, setHistory] = useState<Array<{ role: 'user' | 'assistant'; text: string; emergency?: boolean; language?: string }>>([]);
  const suggestions = ['What should I do for a high fever?', 'Mujhe sar dard ho raha hai', 'Find a pharmacy near Latifabad'];
  const send = (text = message) => {
    const trimmed = text.trim();
    if (!trimmed || chat.isPending) return;
    setHistory((items) => [...items, { role: 'user', text: trimmed }]);
    setMessage('');
    chat.mutate({ data: { message: trimmed, language } }, { onSuccess: (response) => setHistory((items) => [...items, { role: 'assistant', text: response.reply, emergency: response.emergency, language: response.language }]) });
  };
  return <div className="page-enter">
    <SectionHeading eyebrow="Developer demo · guarded responses" title="Ask with context." detail="A bilingual assistant surface for testing safe health-information flows before connecting your care channels." action={<div className="flex items-center gap-2 rounded-full border border-[#e0c994] bg-[#fbf1d8] px-3 py-2 text-xs font-semibold text-[#8b611b]"><Code2 size={14} /> Demo environment</div>} />
    <div className="grid gap-6 xl:grid-cols-[1fr_320px]">
      <section className="flex min-h-[590px] flex-col overflow-hidden rounded-2xl border border-border/80 bg-card shadow-sm">
        <div className="flex items-center justify-between border-b border-border/70 px-5 py-4"><div className="flex items-center gap-3"><span className="grid h-9 w-9 place-items-center rounded-xl bg-primary text-accent"><HeartPulse size={17} /></span><div><p className="text-sm font-semibold text-primary">SehatSaathi assistant</p><p className="flex items-center gap-1.5 text-[11px] text-muted-foreground"><span className="h-1.5 w-1.5 rounded-full bg-[#5ba776]" /> API ready · responses are monitored</p></div></div><button className="rounded-lg p-2 text-muted-foreground hover:bg-muted" onClick={() => setHistory([])} data-testid="button-clear-chat"><Trash2 size={16} /></button></div>
        <div className="flex-1 space-y-4 overflow-y-auto bg-[#f8f5ee]/70 p-5 md:p-7">{history.length === 0 && <div className="flex h-full min-h-[330px] flex-col items-center justify-center text-center"><div className="grid h-16 w-16 place-items-center rounded-[22px] bg-[#e5eee7] text-primary"><Crosshair size={26} /></div><h3 className="mt-5 font-serif text-2xl font-semibold text-primary">A careful second opinion</h3><p className="mt-2 max-w-md text-sm leading-relaxed text-muted-foreground">Try a question in English or Urdu. The assistant will identify urgent situations and explain when to seek in-person care.</p><div className="mt-6 flex flex-wrap justify-center gap-2">{suggestions.map((suggestion) => <button key={suggestion} onClick={() => send(suggestion)} className="rounded-full border border-border bg-card px-3 py-2 text-xs text-primary transition hover:-translate-y-0.5 hover:border-primary/30 hover:bg-muted" data-testid={`button-suggestion-${suggestions.indexOf(suggestion)}`}>{suggestion}</button>)}</div></div>}{history.map((item, index) => <div key={`${item.role}-${index}`} className={`flex ${item.role === 'user' ? 'justify-end' : 'justify-start'}`} data-testid={`chat-message-${index}`}><div className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${item.role === 'user' ? 'rounded-br-md bg-primary text-primary-foreground' : item.emergency ? 'rounded-bl-md border border-[#ca7061]/40 bg-[#f7e3de] text-[#71372e]' : 'rounded-bl-md border border-border/70 bg-card text-foreground'}`}>{item.emergency && <div className="mb-2 flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#a34f43]"><CircleAlert size={14} /> Urgent guidance</div>}{item.text}<div className={`mt-2 text-[10px] ${item.role === 'user' ? 'text-primary-foreground/45' : 'text-muted-foreground'}`}>{item.role === 'assistant' ? `Reply · ${item.language === 'ur' ? 'اردو' : 'English'}` : 'You'}</div></div></div>)}{chat.isPending && <div className="flex items-center gap-2 text-xs text-muted-foreground"><span className="flex gap-1 rounded-2xl rounded-bl-md border border-border bg-card px-4 py-3"><i className="h-1.5 w-1.5 animate-bounce rounded-full bg-primary" /><i className="h-1.5 w-1.5 animate-bounce rounded-full bg-primary [animation-delay:120ms]" /><i className="h-1.5 w-1.5 animate-bounce rounded-full bg-primary [animation-delay:240ms]" /></span>Thinking carefully…</div>}{chat.isError && <ErrorNotice label="The assistant could not respond. Check the connection and try again." />}</div>
        <div className="border-t border-border/70 bg-card p-4"><div className="flex items-center gap-2 rounded-xl border border-input bg-background p-2 focus-within:border-primary/50 focus-within:ring-2 focus-within:ring-accent/30"><textarea value={message} onChange={(event) => setMessage(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); send(); } }} placeholder="Ask a health-information question…" rows={2} maxLength={2000} className="min-h-[44px] flex-1 resize-none bg-transparent px-2 py-1 text-sm outline-none placeholder:text-muted-foreground/70" data-testid="input-chat-message" /><div className="flex flex-col items-end gap-2"><select value={language} onChange={(event) => setLanguage(event.target.value as 'auto' | 'en' | 'ur')} className="rounded-md bg-muted px-2 py-1 text-[10px] font-semibold text-primary outline-none" data-testid="select-chat-language"><option value="auto">AUTO</option><option value="en">ENGLISH</option><option value="ur">اردو</option></select><button disabled={!message.trim() || chat.isPending} onClick={() => send()} className="grid h-9 w-9 place-items-center rounded-lg bg-accent text-accent-foreground transition hover:bg-[#e8ad43] disabled:cursor-not-allowed disabled:opacity-40" data-testid="button-send-chat"><Send size={16} /></button></div></div><p className="mt-2 px-1 text-[10px] text-muted-foreground">Press Enter to send · Shift + Enter for a new line</p></div>
      </section>
      <aside className="space-y-4"><div className="rounded-2xl border border-[#e1c78e] bg-[#fbf1d8] p-5"><div className="flex items-center gap-2 text-[#8f641f]"><CircleAlert size={17} /><p className="text-xs font-bold uppercase tracking-[.15em]">Emergency protocol</p></div><p className="mt-4 text-sm leading-relaxed text-[#745426]">For breathing difficulty, chest pain, severe bleeding, unconsciousness, or a medical emergency, call local emergency services immediately.</p><div className="mt-4 rounded-xl bg-[#f4e4bd] p-3 text-xs font-semibold text-[#745426]">This demo never diagnoses or replaces a clinician.</div></div><div className="rounded-2xl border border-border/80 bg-card p-5 shadow-sm"><p className="text-[10px] font-bold uppercase tracking-[.16em] text-muted-foreground">Response contract</p><div className="mt-4 space-y-3">{['Bilingual output', 'Emergency flagging', 'Demo mode disclosure'].map((label) => <div key={label} className="flex items-center gap-2 text-sm text-primary"><span className="grid h-5 w-5 place-items-center rounded-full bg-[#dce9e3] text-[#2e6659]"><Check size={12} strokeWidth={3} /></span>{label}</div>)}</div></div></aside>
    </div>
  </div>;
}

function Reminders() {
  const qc = useQueryClient();
  const list = useListReminders({ query: { queryKey: getListRemindersQueryKey() } });
  const create = useCreateReminder();
  const remove = useDeleteReminder();
  const [text, setText] = useState('');
  const [time, setTime] = useState('09:00');
  const [formError, setFormError] = useState('');
  const submit = () => {
    if (!text.trim()) { setFormError('Add a short reminder first.'); return; }
    setFormError('');
    create.mutate({ data: { reminderText: text.trim(), reminderTime: time, timezone: 'Asia/Karachi' } }, { onSuccess: () => { setText(''); qc.invalidateQueries({ queryKey: getListRemindersQueryKey() }); qc.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); } });
  };
  const reminders = list.data ?? [];
  return <div className="page-enter"><SectionHeading eyebrow="Follow-up rhythm" title="Reminders that respect the day." detail="Keep small care commitments visible to your team. Times are saved in Pakistan Standard Time." /><div className="grid gap-6 lg:grid-cols-[340px_1fr]"><section className="h-fit rounded-2xl border border-border/80 bg-primary p-5 text-primary-foreground shadow-md md:p-6"><div className="flex items-center gap-2 text-accent"><Plus size={17} /><p className="text-[10px] font-bold uppercase tracking-[.18em]">New reminder</p></div><h3 className="mt-5 font-serif text-2xl font-semibold">What needs a nudge?</h3><label className="mt-6 block text-xs font-semibold text-primary-foreground/70" htmlFor="reminder-text">Reminder note</label><input id="reminder-text" value={text} onChange={(event) => setText(event.target.value)} maxLength={120} placeholder="e.g. Call Ayesha about her report" className="mt-2 w-full rounded-xl border border-primary-foreground/15 bg-primary-foreground/10 px-3 py-3 text-sm outline-none placeholder:text-primary-foreground/35 focus:border-accent" data-testid="input-reminder-text" /><label className="mt-4 block text-xs font-semibold text-primary-foreground/70" htmlFor="reminder-time">Time · PKT</label><input id="reminder-time" type="time" value={time} onChange={(event) => setTime(event.target.value)} className="mt-2 w-full rounded-xl border border-primary-foreground/15 bg-primary-foreground/10 px-3 py-3 text-sm outline-none focus:border-accent" data-testid="input-reminder-time" />{formError && <p className="mt-3 text-xs text-[#f3c4a9]">{formError}</p>}{create.isError && <p className="mt-3 text-xs text-[#f3c4a9]">Could not save this reminder. Please try again.</p>}<button onClick={submit} disabled={create.isPending} className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-accent px-4 py-3 text-sm font-bold text-accent-foreground transition hover:bg-[#e8ad43] disabled:opacity-60" data-testid="button-create-reminder">{create.isPending ? <LoaderCircle size={16} className="animate-spin" /> : <Plus size={16} />}{create.isPending ? 'Saving…' : 'Add reminder'}</button></section><section className="rounded-2xl border border-border/80 bg-card p-5 shadow-sm md:p-6"><div className="flex items-center justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[.18em] text-muted-foreground">Your queue</p><h3 className="mt-1 font-serif text-xl font-semibold text-primary">Active reminders <span className="ml-1 text-sm font-sans font-medium text-muted-foreground">({reminders.length})</span></h3></div><Clock3 className="text-muted-foreground" size={20} /></div>{list.isError ? <div className="mt-5"><ErrorNotice onRetry={() => list.refetch()} label="Reminders are taking a moment to load." /></div> : list.isLoading ? <div className="mt-5 space-y-3">{[1, 2, 3].map((item) => <div key={item} className="h-16 animate-pulse rounded-xl bg-muted" />)}</div> : reminders.length === 0 ? <EmptyState icon={Bell} title="Your queue is clear" detail="Add a reminder when a person or follow-up needs a gentle nudge." /> : <div className="mt-5 space-y-3">{reminders.map((reminder) => <div key={reminder.id} className="group flex items-center gap-3 rounded-xl border border-border/70 bg-background p-3.5 transition hover:border-primary/25 hover:shadow-sm" data-testid={`reminder-${reminder.id}`}><span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#f5e3bd] font-serif text-sm font-bold text-[#946419]">{reminder.reminderTime}</span><div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold text-primary">{reminder.reminderText}</p><p className="mt-1 text-[11px] text-muted-foreground">Pakistan Standard Time · {reminder.active ? 'Active' : 'Paused'}</p></div><button onClick={() => { if (window.confirm('Delete this reminder?')) remove.mutate({ id: reminder.id }, { onSuccess: () => { qc.invalidateQueries({ queryKey: getListRemindersQueryKey() }); qc.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); } }); }} disabled={remove.isPending} className="rounded-lg p-2 text-muted-foreground opacity-60 transition hover:bg-[#f8e9e5] hover:text-destructive group-hover:opacity-100" data-testid={`button-delete-reminder-${reminder.id}`}><Trash2 size={16} /></button></div>)}</div>}</section></div></div>;
}

function Places() {
  const [type, setType] = useState<'all' | 'clinic' | 'pharmacy'>('all');
  const params = useMemo(() => ({ city: 'Hyderabad', ...(type === 'all' ? {} : { type }) }), [type]);
  const places = useListPlaces(params, { query: { queryKey: getListPlacesQueryKey(params) } });
  const items = places.data ?? [];
  return <div className="page-enter"><SectionHeading eyebrow="Local care network" title="Care, close to home." detail="A practical starting point for finding clinics and pharmacies around Hyderabad, Sindh." action={<div className="flex items-center gap-2 rounded-xl border border-border bg-card px-3 py-2 text-xs font-semibold text-primary"><MapPin size={14} className="text-[#b4771e]" /> Hyderabad, Sindh</div>} /><div className="mb-5 flex gap-2 overflow-x-auto pb-1"><button onClick={() => setType('all')} className={`rounded-full px-4 py-2 text-xs font-bold transition ${type === 'all' ? 'bg-primary text-primary-foreground' : 'border border-border bg-card text-muted-foreground hover:text-primary'}`} data-testid="button-filter-all">All places</button><button onClick={() => setType('clinic')} className={`flex items-center gap-2 rounded-full px-4 py-2 text-xs font-bold transition ${type === 'clinic' ? 'bg-primary text-primary-foreground' : 'border border-border bg-card text-muted-foreground hover:text-primary'}`} data-testid="button-filter-clinic"><Hospital size={14} /> Clinics</button><button onClick={() => setType('pharmacy')} className={`flex items-center gap-2 rounded-full px-4 py-2 text-xs font-bold transition ${type === 'pharmacy' ? 'bg-primary text-primary-foreground' : 'border border-border bg-card text-muted-foreground hover:text-primary'}`} data-testid="button-filter-pharmacy"><Pill size={14} /> Pharmacies</button></div><div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{places.isLoading ? [1, 2, 3].map((item) => <div key={item} className="h-52 animate-pulse rounded-2xl bg-muted" />) : places.isError ? <div className="md:col-span-2 xl:col-span-3"><ErrorNotice onRetry={() => places.refetch()} label="Nearby places could not be loaded." /></div> : items.length === 0 ? <div className="md:col-span-2 xl:col-span-3 rounded-2xl border border-border/80 bg-card"><EmptyState icon={MapPin} title="No places found" detail="Try showing all care places in Hyderabad." /></div> : items.map((place) => <article key={place.id} className="group rounded-2xl border border-border/80 bg-card p-5 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-md" data-testid={`place-card-${place.id}`}><div className="flex items-start justify-between"><span className={`grid h-10 w-10 place-items-center rounded-xl ${place.type === 'clinic' ? 'bg-[#dce9e3] text-[#2e6659]' : 'bg-[#e7dfed] text-[#75547e]'}`}>{place.type === 'clinic' ? <Hospital size={18} /> : <Pill size={18} />}</span><span className="rounded-full bg-muted px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{place.distance}</span></div><h3 className="mt-5 font-serif text-xl font-semibold text-primary">{place.name}</h3><p className="mt-1 text-xs text-muted-foreground">{place.type === 'clinic' ? 'Clinic' : 'Pharmacy'} · {place.address}</p><div className="mt-5 flex items-center justify-between border-t border-border/70 pt-4"><span className={`flex items-center gap-1.5 text-xs font-semibold ${place.hoursAvailable ? 'text-[#397b60]' : 'text-muted-foreground'}`}><span className={`h-1.5 w-1.5 rounded-full ${place.hoursAvailable ? 'bg-[#5ba776]' : 'bg-muted-foreground'}`} />{place.hoursAvailable ? 'Open now' : 'Hours unavailable'}</span><a href={place.mapsUrl} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-xs font-bold text-primary hover:text-[#a96f16]" data-testid={`link-map-${place.id}`}>Directions <ExternalLink size={13} /></a></div></article>)}</div></div>;
}

function WhatsApp() {
  const status = useGetWhatsAppStatus({ query: { queryKey: getGetWhatsAppStatusQueryKey(), refetchInterval: 60000 } });
  const info = status.data;
  return <div className="page-enter"><SectionHeading eyebrow="Channel operations" title="WhatsApp, made accountable." detail="See what the connected channel is receiving and sending, without losing the human context behind each message." action={<button onClick={() => status.refetch()} className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-4 py-3 text-xs font-bold text-primary hover:bg-muted" data-testid="button-refresh-whatsapp"><RefreshCw size={14} /> Refresh status</button>} /><div className="grid gap-6 lg:grid-cols-[.8fr_1.2fr]"><section className="rounded-2xl border border-border/80 bg-card p-6 shadow-sm"><div className="flex items-start justify-between"><div className="grid h-12 w-12 place-items-center rounded-2xl bg-[#dce9e3] text-[#2e6659]"><Smartphone size={22} /></div><span className={`rounded-full px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider ${info?.connected ? 'bg-[#dce9e3] text-[#397b60]' : 'bg-[#f5e3bd] text-[#946419]'}`}>{info?.connected ? 'Connected' : 'Demo mode'}</span></div><h3 className="mt-7 font-serif text-2xl font-semibold text-primary">WhatsApp Cloud API</h3><p className="mt-2 text-sm leading-relaxed text-muted-foreground">{info?.connected ? 'Messages are flowing through the configured business number.' : 'Preview the message flow while credentials are not connected.'}</p><div className="mt-7 rounded-xl bg-muted p-4"><p className="text-[10px] font-bold uppercase tracking-[.16em] text-muted-foreground">Business number</p><p className="mt-2 font-mono text-sm text-primary" data-testid="text-whatsapp-number">{status.isLoading ? 'Loading…' : info?.phoneNumber || 'Not configured'}</p></div><Link href="/settings" className="mt-5 inline-flex items-center gap-2 text-sm font-bold text-primary hover:text-[#a96f16]" data-testid="link-whatsapp-settings">View integration guidance <ArrowUpRight size={15} /></Link></section><section className="rounded-2xl border border-border/80 bg-card p-6 shadow-sm"><div className="flex items-center justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[.16em] text-muted-foreground">Sample flow</p><h3 className="mt-1 font-serif text-xl font-semibold text-primary">Recent messages</h3></div><span className="rounded-lg bg-muted px-2 py-1 text-[10px] font-semibold text-muted-foreground">{info?.messages?.length ?? 0} events</span></div>{status.isError ? <div className="mt-5"><ErrorNotice onRetry={() => status.refetch()} label="WhatsApp status could not be loaded." /></div> : status.isLoading ? <div className="mt-5 space-y-3">{[1, 2, 3].map((item) => <div key={item} className="h-16 animate-pulse rounded-xl bg-muted" />)}</div> : info?.messages?.length ? <div className="mt-5 space-y-3">{info.messages.map((message) => <div key={message.id} className={`flex ${message.direction === 'outbound' ? 'justify-end' : 'justify-start'}`} data-testid={`whatsapp-message-${message.id}`}><div className={`max-w-[85%] rounded-2xl px-4 py-3 ${message.direction === 'outbound' ? 'rounded-br-md bg-primary text-primary-foreground' : 'rounded-bl-md bg-muted text-primary'}`}><p className="text-sm leading-relaxed">{message.text}</p><p className={`mt-2 text-[10px] ${message.direction === 'outbound' ? 'text-primary-foreground/45' : 'text-muted-foreground'}`}>{formatTime(message.timestamp)} · {message.language === 'ur' ? 'اردو' : 'English'}</p></div></div>)}</div> : <EmptyState icon={MessageCircle} title="No message events" detail="Inbound and outbound messages will be visible here once the channel is active." compact />}</section></div></div>;
}

function SettingsPage() {
  const [demo, setDemo] = useState(true);
  const health = useHealthCheck({ query: { queryKey: getHealthCheckQueryKey() } });
  return <div className="page-enter"><SectionHeading eyebrow="Workspace controls" title="Settings with a safety rail." detail="Keep the demo honest, the boundaries visible, and the next integration step clear." /><div className="grid gap-6 lg:grid-cols-[1fr_360px]"><div className="space-y-5"><section className="rounded-2xl border border-border/80 bg-card p-6 shadow-sm"><div className="flex items-start justify-between gap-5"><div><div className="flex items-center gap-2"><ShieldCheck size={18} className="text-[#397b60]" /><h3 className="font-serif text-xl font-semibold text-primary">Demo mode</h3></div><p className="mt-2 max-w-lg text-sm leading-relaxed text-muted-foreground">Keep demo responses labelled while you test the assistant and message flows with your care team.</p></div><button role="switch" aria-checked={demo} onClick={() => setDemo(!demo)} className={`relative h-7 w-12 shrink-0 rounded-full p-1 transition ${demo ? 'bg-primary' : 'bg-muted-foreground/30'}`} data-testid="button-toggle-demo-mode"><span className={`block h-5 w-5 rounded-full bg-accent transition-transform ${demo ? 'translate-x-5' : ''}`} /></button></div><div className="mt-5 flex items-center gap-2 border-t border-border/70 pt-4 text-xs font-semibold text-primary"><span className={`h-2 w-2 rounded-full ${demo ? 'bg-[#5ba776]' : 'bg-muted-foreground'}`} />{demo ? 'Demo responses are clearly marked' : 'Live mode selected'}</div></section><section className="rounded-2xl border border-[#e1c78e] bg-[#fbf1d8] p-6"><div className="flex gap-3"><CircleAlert className="mt-0.5 shrink-0 text-[#a36c18]" size={19} /><div><h3 className="font-serif text-xl font-semibold text-[#744f18]">Safety disclaimer</h3><p className="mt-3 text-sm leading-relaxed text-[#745426]">SehatSaathi provides general health information, not medical diagnosis or treatment. Never delay urgent care because of a response here. When symptoms are severe, worsening, or unclear, contact a qualified healthcare professional.</p></div></div></section><section className="rounded-2xl border border-border/80 bg-card p-6 shadow-sm"><div className="flex items-center gap-2"><Settings size={18} className="text-primary" /><h3 className="font-serif text-xl font-semibold text-primary">Integration guidance</h3></div><div className="mt-5 space-y-4">{[['01', 'WhatsApp Cloud API', 'Add your phone number ID and access token on the server, then verify the webhook.'], ['02', 'Places directory', 'Connect a trusted local directory for more complete Hyderabad coverage.'], ['03', 'Care team review', 'Have a clinician review safety copy before moving beyond demo mode.']].map(([number, title, detail]) => <div key={number} className="flex gap-4 border-t border-border/70 pt-4 first:border-0 first:pt-0"><span className="font-mono text-xs font-bold text-[#a36c18]">{number}</span><div><p className="text-sm font-bold text-primary">{title}</p><p className="mt-1 text-xs leading-relaxed text-muted-foreground">{detail}</p></div></div>)}</div></section></div><aside className="h-fit rounded-2xl bg-primary p-6 text-primary-foreground shadow-md"><p className="text-[10px] font-bold uppercase tracking-[.18em] text-accent">System check</p><h3 className="mt-5 font-serif text-2xl font-semibold">Quietly ready.</h3><div className="mt-6 space-y-3">{[['API server', health.isError ? 'Needs attention' : 'Healthy', !health.isError], ['Workspace', 'Demo workspace', true], ['Region', 'Hyderabad · PKT', true]].map(([key, value, good]) => <div key={key as string} className="flex items-center justify-between border-b border-primary-foreground/10 pb-3 text-sm last:border-0"><span className="text-primary-foreground/55">{key}</span><span className="flex items-center gap-2 font-semibold">{good ? <span className="h-1.5 w-1.5 rounded-full bg-[#91d9aa]" /> : <span className="h-1.5 w-1.5 rounded-full bg-[#f0ad74]" />}{value}</span></div>)}</div></aside></div></div>;
}

function Router() {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}><Shell><Switch><Route path="/" component={Overview} /><Route path="/assistant" component={Assistant} /><Route path="/reminders" component={Reminders} /><Route path="/places" component={Places} /><Route path="/whatsapp" component={WhatsApp} /><Route path="/settings" component={SettingsPage} /><Route component={NotFound} /></Switch></Shell></ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;