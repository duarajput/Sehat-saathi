import { Router, type IRouter } from "express";
import healthRouter from "./health";
import dashboardRouter from "./dashboard";
import assistantRouter from "./assistant";
import remindersRouter from "./reminders";
import placesRouter from "./places";
import whatsappRouter from "./whatsapp";

const router: IRouter = Router();

router.use(healthRouter);
router.use(dashboardRouter);
router.use(assistantRouter);
router.use(remindersRouter);
router.use(placesRouter);
router.use(whatsappRouter);

export default router;
