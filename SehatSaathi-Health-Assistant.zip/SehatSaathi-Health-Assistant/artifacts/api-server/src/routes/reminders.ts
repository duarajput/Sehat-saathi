import { Router, type IRouter } from "express";
import {
  CreateReminderBody,
  CreateReminderResponse,
  DeleteReminderParams,
  ListRemindersResponse,
} from "@workspace/api-zod";
import { addReminder, getReminders, removeReminder } from "../services/store";

const router: IRouter = Router();

router.get("/reminders", (_req, res) => {
  res.json(ListRemindersResponse.parse(getReminders()));
});

router.post("/reminders", (req, res) => {
  const parsed = CreateReminderBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Add a reminder note and a valid time such as 09:00." });
    return;
  }
  const reminder = addReminder(parsed.data);
  res.status(201).json(CreateReminderResponse.parse(reminder));
});

router.delete("/reminders/:id", (req, res) => {
  const parsed = DeleteReminderParams.safeParse(req.params);
  if (!parsed.success || !removeReminder(parsed.data.id)) {
    res.status(404).json({ error: "Reminder not found." });
    return;
  }
  res.status(204).send();
});

export default router;