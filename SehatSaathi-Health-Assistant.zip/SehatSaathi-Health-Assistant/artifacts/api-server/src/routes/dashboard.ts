import { Router, type IRouter } from "express";
import { GetDashboardResponse } from "@workspace/api-zod";
import { getActivities, getMessageCount, getReminders } from "../services/store";

const router: IRouter = Router();

router.get("/dashboard", (req, res) => {
  const data = GetDashboardResponse.parse({
    totalUsers: 128,
    messagesProcessed: getMessageCount(),
    healthQuestionsToday: 38,
    activeReminders: getReminders().length,
    demoMode: !process.env.GEMINI_API_KEY,
    recentActivity: getActivities(),
  });
  req.log.info({ demoMode: data.demoMode }, "Dashboard summary requested");
  res.json(data);
});

export default router;