import { Router, type IRouter } from "express";
import { handleIncomingText, isWhatsAppConfigured, sendWhatsAppText } from "../services/whatsapp";

const router: IRouter = Router();

router.get("/webhook/whatsapp", (req, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];
  if (mode === "subscribe" && token && token === process.env.WHATSAPP_VERIFY_TOKEN) {
    res.status(200).send(challenge);
    return;
  }
  res.status(403).send("Webhook verification failed.");
});

router.post("/webhook/whatsapp", async (req, res) => {
  res.sendStatus(200);
  if (!isWhatsAppConfigured()) return;

  const entries = Array.isArray(req.body?.entry) ? req.body.entry : [];
  for (const entry of entries) {
    const changes = Array.isArray(entry?.changes) ? entry.changes : [];
    for (const change of changes) {
      const messages = Array.isArray(change?.value?.messages) ? change.value.messages : [];
      for (const message of messages) {
        const from = typeof message?.from === "string" ? message.from : "";
        if (!from) continue;
        if (message?.type === "text" && typeof message?.text?.body === "string") {
          await handleIncomingText(from, message.text.body);
        } else if (message?.type === "audio") {
          await sendWhatsAppText(from, "Voice messages are not available yet. Please send your health question as text, or contact a qualified healthcare professional for urgent concerns.");
        }
      }
    }
  }
});

export default router;