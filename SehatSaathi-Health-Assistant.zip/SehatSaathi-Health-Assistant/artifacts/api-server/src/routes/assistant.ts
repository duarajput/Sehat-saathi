import { Router, type IRouter } from "express";
import { SendChatMessageResponse, SendChatMessageBody } from "@workspace/api-zod";
import { answerHealthQuestion } from "../services/health-assistant";
import { recordMessage } from "../services/store";

const router: IRouter = Router();

router.post("/chat", async (req, res) => {
  const parsed = SendChatMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Please provide a message up to 2,000 characters." });
    return;
  }

  const answer = await answerHealthQuestion(parsed.data.message, parsed.data.language);
  recordMessage();
  req.log.info({ language: answer.language, emergency: answer.emergency, demoMode: answer.demoMode }, "Health question answered");
  res.json(SendChatMessageResponse.parse(answer));
});

export default router;