import { Router, type IRouter } from "express";
import { GetWhatsAppStatusResponse } from "@workspace/api-zod";
import { getWhatsAppMessages } from "../services/store";
import { isWhatsAppConfigured } from "../services/whatsapp";

const router: IRouter = Router();

router.get("/whatsapp/status", (_req, res) => {
  const connected = isWhatsAppConfigured();
  res.json(GetWhatsAppStatusResponse.parse({
    connected,
    demoMode: !connected,
    phoneNumber: connected ? process.env.WHATSAPP_PHONE_NUMBER_ID : "",
    messages: getWhatsAppMessages(),
  }));
});

export default router;