import { Router, type IRouter } from "express";
import { ListPlacesQueryParams, ListPlacesResponse } from "@workspace/api-zod";
import { findPlaces } from "../services/places";

const router: IRouter = Router();

router.get("/places", async (req, res) => {
  const parsed = ListPlacesQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "Choose clinic or pharmacy and try again." });
    return;
  }
  const places = await findPlaces(
    parsed.data.type,
    parsed.data.city,
    parsed.data.latitude,
    parsed.data.longitude,
  );
  res.json(ListPlacesResponse.parse(places));
});

export default router;