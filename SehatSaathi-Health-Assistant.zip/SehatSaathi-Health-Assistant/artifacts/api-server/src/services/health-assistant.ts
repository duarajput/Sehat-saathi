const SYSTEM_PROMPT = `You are SehatSaathi, a health-information assistant for users in Pakistan.
Provide safe, general health information in the user's preferred language, Urdu or English.
You are not a doctor and must not diagnose diseases. Do not prescribe prescription medicines,
change medication doses, or tell users to stop prescribed treatment. Give conservative self-care
information when appropriate. If symptoms could indicate an emergency, clearly recommend urgent
professional medical help. Ask relevant clarifying questions when necessary. Keep responses concise,
understandable, respectful, and culturally appropriate. Never invent medical facts, clinic information,
or emergency numbers.`;

const urgentPatterns = [
  /\b(chest pain|severe chest|difficulty breathing|can't breathe|cannot breathe|shortness of breath)\b/i,
  /\b(unconscious|passed out|seizure|convulsion|severe bleeding|poison|overdose|anaphylaxis)\b/i,
  /\b(seene mein dard|saans lene mein mushkil|saans nahi|behosh|mirgi|dora|bohat khoon|zehar|overdose|sakht allergy)\b/i,
];

function detectLanguage(message: string, requested: "ur" | "en" | "auto" = "auto") {
  if (requested !== "auto") return requested;
  if (/[\u0600-\u06ff]/.test(message)) return "ur" as const;
  if (/\b(mujhe|hai|ho raha|rahi|bukhar|dard|qareeb|batao|peete|aaram)\b/i.test(message)) {
    return "ur" as const;
  }
  return "en" as const;
}

function isEmergency(message: string) {
  return urgentPatterns.some((pattern) => pattern.test(message));
}

function demoReply(message: string, language: "ur" | "en", emergency: boolean) {
  if (emergency && language === "ur") {
    return "Yeh alamat emergency ho sakti hain. Abhi foran qualified medical professional ya local emergency service se rabta karein, aur agar mumkin ho to kisi bharosemand shakhs ko apne paas bulayen. Main diagnosis nahi kar sakta.";
  }
  if (emergency) {
    return "These symptoms may be an emergency. Please contact a qualified medical professional or local emergency service immediately, and ask someone you trust to stay with you if possible. I cannot diagnose a condition.";
  }
  if (language === "ur") {
    return "Aapko jo symptoms hain un par nazar rakhein, pani peete rahen aur aaram karein. Agar symptoms barhein, naye severe symptoms hon, ya aap pareshan hon to qualified doctor se mashwara karein. Main diagnosis nahi kar sakta. Kya aap bata sakte hain ke yeh kab shuru hue aur aapki umar kya hai?";
  }
  return "Please monitor your symptoms, drink water, and rest if you can. If they worsen, new severe symptoms appear, or you are worried, speak with a qualified clinician. I cannot diagnose a condition. When did this start, and how old is the person affected?";
}

async function askGemini(message: string, language: "ur" | "en") {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 10000);
  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(apiKey)}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: controller.signal,
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
          contents: [{ role: "user", parts: [{ text: `Reply in ${language === "ur" ? "Urdu or simple Roman Urdu" : "English"}.\n\n${message}` }] }],
          generationConfig: { maxOutputTokens: 8192, temperature: 0.2 },
        }),
      },
    );
    if (!response.ok) return null;
    const payload = (await response.json()) as {
      candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
    };
    return payload.candidates?.[0]?.content?.parts?.map((part) => part.text ?? "").join("").trim() || null;
  } catch {
    return null;
  } finally {
    clearTimeout(timeout);
  }
}

export async function answerHealthQuestion(message: string, requestedLanguage: "ur" | "en" | "auto" = "auto") {
  const language = detectLanguage(message, requestedLanguage);
  const emergency = isEmergency(message);
  const liveReply = emergency ? null : await askGemini(message, language);
  return {
    reply: liveReply ?? demoReply(message, language, emergency),
    language,
    emergency,
    demoMode: !liveReply,
  };
}

export { SYSTEM_PROMPT };