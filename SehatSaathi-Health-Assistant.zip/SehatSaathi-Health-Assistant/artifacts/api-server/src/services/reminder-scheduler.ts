import { logger } from "../lib/logger";
import { getReminders } from "./store";
import { sendWhatsAppText } from "./whatsapp";

const delivered = new Set<string>();

function localTime(timeZone: string) {
  return new Intl.DateTimeFormat("en-GB", {
    timeZone,
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).format(new Date());
}

export function startReminderScheduler() {
  const tick = async () => {
    const now = new Date();
    for (const reminder of getReminders()) {
      const key = `${reminder.id}:${now.toISOString().slice(0, 10)}`;
      if (reminder.phoneNumber && localTime(reminder.timezone) === reminder.reminderTime && !delivered.has(key)) {
        const sent = await sendWhatsAppText(
          reminder.phoneNumber,
          `SehatSaathi Reminder: It's time for the reminder you scheduled — ${reminder.reminderText}.`,
        );
        if (sent) delivered.add(key);
      }
    }
  };

  void tick();
  const interval = setInterval(() => void tick(), 60_000);
  interval.unref();
  logger.info("Reminder scheduler started");
}