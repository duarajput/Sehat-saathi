import { answerHealthQuestion } from "./health-assistant";
import { recordWhatsAppMessage } from "./store";

export function isWhatsAppConfigured() {
  return Boolean(process.env.WHATSAPP_ACCESS_TOKEN && process.env.WHATSAPP_PHONE_NUMBER_ID);
}

export async function sendWhatsAppText(to: string, text: string) {
  const token = process.env.WHATSAPP_ACCESS_TOKEN;
  const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID;
  if (!token || !phoneNumberId) return false;
  try {
    const response = await fetch(`https://graph.facebook.com/v21.0/${phoneNumberId}/messages`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify({ messaging_product: "whatsapp", to, type: "text", text: { body: text } }),
      signal: AbortSignal.timeout(10000),
    });
    return response.ok;
  } catch {
    return false;
  }
}

export async function handleIncomingText(from: string, text: string, language: "ur" | "en" | "auto" = "auto") {
  const answer = await answerHealthQuestion(text, language);
  recordWhatsAppMessage({ direction: "inbound", text, language: answer.language });
  const sent = await sendWhatsAppText(from, answer.reply);
  if (sent) recordWhatsAppMessage({ direction: "outbound", text: answer.reply, language: answer.language });
  return answer;
}