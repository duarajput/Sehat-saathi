import { randomUUID } from "node:crypto";

export type Reminder = {
  id: string;
  phoneNumber: string | null;
  reminderText: string;
  reminderTime: string;
  timezone: string;
  active: boolean;
  createdAt: string;
};

export type Activity = {
  id: string;
  title: string;
  detail: string;
  time: string;
  kind: "message" | "reminder" | "whatsapp" | "place";
};

export type WhatsAppMessage = {
  id: string;
  direction: "inbound" | "outbound";
  text: string;
  timestamp: string;
  language: "ur" | "en";
};

const demoNow = new Date("2024-06-18T08:30:00+05:00");

const reminders: Reminder[] = [
  {
    id: "rem-demo-1",
    phoneNumber: null,
    reminderText: "Check in with Ayesha",
    reminderTime: "09:00",
    timezone: "Asia/Karachi",
    active: true,
    createdAt: demoNow.toISOString(),
  },
  {
    id: "rem-demo-2",
    phoneNumber: null,
    reminderText: "Review evening care notes",
    reminderTime: "18:30",
    timezone: "Asia/Karachi",
    active: true,
    createdAt: demoNow.toISOString(),
  },
];

const activities: Activity[] = [
  {
    id: "activity-1",
    title: "Urdu health question answered",
    detail: "General guidance shared with emergency boundaries included.",
    time: "2024-06-18T08:12:00+05:00",
    kind: "message",
  },
  {
    id: "activity-2",
    title: "Reminder scheduled",
    detail: "Check in with Ayesha · 09:00 PKT",
    time: "2024-06-18T07:45:00+05:00",
    kind: "reminder",
  },
  {
    id: "activity-3",
    title: "Nearby places viewed",
    detail: "Hyderabad care directory opened by the care team.",
    time: "2024-06-18T07:18:00+05:00",
    kind: "place",
  },
];

const whatsappMessages: WhatsAppMessage[] = [
  {
    id: "wa-demo-1",
    direction: "inbound",
    text: "Mujhe raat se bukhar hai aur sar dard ho raha hai.",
    timestamp: "2024-06-18T08:12:00+05:00",
    language: "ur",
  },
  {
    id: "wa-demo-2",
    direction: "outbound",
    text: "Aap pani peete rahen aur aaram karein. Agar bukhar bohat zyada ho ya halat kharab hoti jaye to qualified doctor se foran rabta karein. Main diagnosis nahi kar sakta.",
    timestamp: "2024-06-18T08:12:08+05:00",
    language: "ur",
  },
];

let messageCount = 2847;

export function getReminders() {
  return reminders.filter((reminder) => reminder.active);
}

export function addReminder(input: {
  phoneNumber?: string;
  reminderText: string;
  reminderTime: string;
  timezone: string;
}) {
  const reminder: Reminder = {
    id: randomUUID(),
    phoneNumber: input.phoneNumber ?? null,
    reminderText: input.reminderText,
    reminderTime: input.reminderTime,
    timezone: input.timezone,
    active: true,
    createdAt: new Date().toISOString(),
  };
  reminders.unshift(reminder);
  activities.unshift({
    id: `activity-${randomUUID()}`,
    title: "Reminder scheduled",
    detail: `${reminder.reminderText} · ${reminder.reminderTime}`,
    time: reminder.createdAt,
    kind: "reminder",
  });
  return reminder;
}

export function removeReminder(id: string) {
  const index = reminders.findIndex((reminder) => reminder.id === id);
  if (index === -1) return false;
  reminders.splice(index, 1);
  return true;
}

export function getActivities() {
  return activities.slice(0, 6);
}

export function getMessageCount() {
  return messageCount;
}

export function recordMessage() {
  messageCount += 1;
}

export function getWhatsAppMessages() {
  return whatsappMessages.slice(-10);
}

export function recordWhatsAppMessage(message: Omit<WhatsAppMessage, "id" | "timestamp">) {
  whatsappMessages.push({
    ...message,
    id: `wa-${randomUUID()}`,
    timestamp: new Date().toISOString(),
  });
}