type Place = {
  id: string;
  name: string;
  type: "clinic" | "pharmacy";
  address: string;
  distance: string;
  mapsUrl: string;
  hoursAvailable: boolean;
};

const demoPlaces: Place[] = [
  {
    id: "place-clinic-1",
    name: "Liaquat University Hospital",
    type: "clinic",
    address: "Jamshoro Road, Hyderabad",
    distance: "2.4 km",
    mapsUrl: "https://www.google.com/maps/search/?api=1&query=Liaquat+University+Hospital+Hyderabad+Sindh",
    hoursAvailable: false,
  },
  {
    id: "place-clinic-2",
    name: "Isra University Hospital",
    type: "clinic",
    address: "Hala Road, Hyderabad",
    distance: "4.1 km",
    mapsUrl: "https://www.google.com/maps/search/?api=1&query=Isra+University+Hospital+Hyderabad+Sindh",
    hoursAvailable: false,
  },
  {
    id: "place-pharmacy-1",
    name: "D Watson Pharmacy",
    type: "pharmacy",
    address: "Autobhan Road, Latifabad",
    distance: "1.8 km",
    mapsUrl: "https://www.google.com/maps/search/?api=1&query=D+Watson+Pharmacy+Latifabad+Hyderabad+Sindh",
    hoursAvailable: false,
  },
  {
    id: "place-pharmacy-2",
    name: "Clinix Pharmacy",
    type: "pharmacy",
    address: "Qasimabad, Hyderabad",
    distance: "3.6 km",
    mapsUrl: "https://www.google.com/maps/search/?api=1&query=Clinix+Pharmacy+Qasimabad+Hyderabad+Sindh",
    hoursAvailable: false,
  },
];

export async function findPlaces(type: "clinic" | "pharmacy", city: string, latitude?: number, longitude?: number) {
  const apiKey = process.env.GOOGLE_MAPS_API_KEY;
  if (!apiKey) return demoPlaces.filter((place) => place.type === type);

  try {
    const response = await fetch("https://places.googleapis.com/v1/places:searchText", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Goog-Api-Key": apiKey,
        "X-Goog-FieldMask": "places.id,places.displayName,places.formattedAddress,places.googleMapsUri",
      },
      body: JSON.stringify({
        textQuery: `${type} in ${city}, Pakistan`,
        ...(latitude !== undefined && longitude !== undefined
          ? { locationBias: { circle: { center: { latitude, longitude }, radius: 10000 } } }
          : {}),
      }),
      signal: AbortSignal.timeout(10000),
    });
    if (!response.ok) return demoPlaces.filter((place) => place.type === type);
    const payload = (await response.json()) as {
      places?: Array<{ id?: string; displayName?: { text?: string }; formattedAddress?: string; googleMapsUri?: string }>;
    };
    const places = payload.places ?? [];
    if (!places.length) return demoPlaces.filter((place) => place.type === type);
    return places.slice(0, 8).map((place, index): Place => ({
      id: place.id ?? `google-place-${index}`,
      name: place.displayName?.text ?? `${type === "clinic" ? "Clinic" : "Pharmacy"} near ${city}`,
      type,
      address: place.formattedAddress ?? city,
      distance: "Distance unavailable",
      mapsUrl: place.googleMapsUri ?? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${type} ${city} Pakistan`)}`,
      hoursAvailable: false,
    }));
  } catch {
    return demoPlaces.filter((place) => place.type === type);
  }
}